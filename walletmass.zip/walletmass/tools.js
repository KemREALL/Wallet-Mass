const { Wallet } = require("ethers");
const fs = require("fs");
const chalk = require("chalk");
const figlet = require("figlet");
const ora = require("ora");
const cliProgress = require("cli-progress");
const inquirer = require("inquirer");
const gradient = require("gradient-string");

const OWNER_NAME = "Kem";
const TOOL_VERSION = "v1.0.0";

// ===== LOGO =====
function showLogo() {
  console.clear();
  console.log(
    gradient.atlas(
      figlet.textSync("KEM TOOLS", { horizontalLayout: "full" })
    )
  );

  console.log(
    chalk.cyan.bold(`\nCreated by ${OWNER_NAME} | ${TOOL_VERSION}`)
  );

  console.log(
    chalk.white.bold("Buat Wallet EVM Massal") + "\n" +
    chalk.gray("Ngapain Capek-Capek Manual\n")
  );
}

// ===== GENERATE WALLET =====
function generateWallet() {
  const wallet = Wallet.createRandom();
  return {
    address: wallet.address,
    privateKey: wallet.privateKey,
    mnemonic: wallet.mnemonic.phrase
  };
}

// ===== WALLET FEATURE =====
async function walletGenerator() {
  const answers = await inquirer.prompt([
    {
      type: "input",
      name: "jumlah",
      message: "Masukkan jumlah wallet:",
      validate: function(value) {
        if (!isNaN(value) && value > 0) return true;
        return "Masukkan angka yang valid.";
      }
    }
  ]);

  const JUMLAH_WALLET = parseInt(answers.jumlah);
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const OUTPUT_FILE = `kem_wallets_${timestamp}.csv`;

  const spinner = ora("Initializing generator...").start();
  await new Promise(resolve => setTimeout(resolve, 1000));
  spinner.succeed("System ready.\n");

  const progressBar = new cliProgress.SingleBar({
    format: 'Generating |{bar}| {percentage}% | {value}/{total}',
    barCompleteChar: '\u2588',
    barIncompleteChar: '\u2591',
    hideCursor: true
  });

  progressBar.start(JUMLAH_WALLET, 0);

  let data = "No,Address,PrivateKey,Mnemonic\n";

  for (let i = 0; i < JUMLAH_WALLET; i++) {
    const wallet = generateWallet();
    data += `${i+1},${wallet.address},${wallet.privateKey},"${wallet.mnemonic}"\n`;
    progressBar.increment();
  }

  progressBar.stop();

  fs.writeFileSync(OUTPUT_FILE, data);

  console.log(chalk.green("\n✔ Wallet generation completed"));
  console.log(chalk.blue(`✔ Saved to ${OUTPUT_FILE}\n`));
}

// ===== MAIN MENU =====
async function main() {
  showLogo();

  const answers = await inquirer.prompt([
    {
      type: "list",
      name: "menu",
      message: "Pilih fitur:",
      choices: [
        "Generate Wallet EVM Massal",
        "Exit"
      ]
    }
  ]);

  if (answers.menu === "Generate Wallet EVM Massal") {
    await walletGenerator();
  } else {
    console.log(chalk.red("\nExiting KEM TOOLS...\n"));
    process.exit();
  }

  console.log(chalk.magenta("Thank you for using KEM TOOLS\n"));
}

main();
