npm install
node tools.js


npm install ethers@5 chalk@4 inquirer@8 ora@5 figlet cli-progress gradient-string
